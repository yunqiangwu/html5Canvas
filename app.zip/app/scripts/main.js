console.log('\'Allo \'Allo!');




var GameCanvasContext = window.GameCanvasContext;


function initCanvas() {
	GameCanvasContext.init();
}

$(function () {


	
	initCanvas() ;
	
})
